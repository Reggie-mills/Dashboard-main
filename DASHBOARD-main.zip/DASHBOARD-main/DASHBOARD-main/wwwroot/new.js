
    function showAlert(message) {
    alert(message);
}
function redirectTo(url) {
    window.location.href = url;
}
